/**
 * @file frame_analyzer_parser.h
 * @author risinek (risinek@gmail.com)
 * @date 2021-04-05
 * @copyright Copyright (c) 2021
 * 
 * @brief Provides interface for parsing functionality
 */
#ifndef FRAME_ANALYZER_PARSER_H
#define FRAME_ANALYZER_PARSER_H

#include <stdint.h>
#include <stdbool.h>
#include "esp_event.h"
#include "esp_wifi_types.h"

#include "frame_analyzer_types.h"

ESP_EVENT_DECLARE_BASE(FRAME_ANALYZER_EVENTS);

void print_raw_frame(const wifi_promiscuous_pkt_t *frame);
void print_mac_address(const uint8_t *a);

/**
 * @brief Determines whether BSSID inside of the given frame matches given BSSID.
 * 
 * @param frame 
 * @param bssid 
 * @return bool 
 */
bool is_frame_bssid_matching(wifi_promiscuous_pkt_t *frame, uint8_t *bssid);

/**
 * @brief Parses EAPoL packet from given frame.
 * 
 * @param frame 
 * @return eapol_packet_t* if parsing successful 
 * @return \c NULL if no EAPoL packet was found
 * @return \c NULL if frame is protected
 */
eapol_packet_t *parse_eapol_packet(data_frame_t *frame);

/**
 * @brief Parses EAPoL-Key packet from EAPoL packet
 * 
 * @param eapol_packet 
 * @return eapol_key_packet_t* if parsing successful
 * @return \c NULL if no EAPoL-Key packet found
 */
eapol_key_packet_t *parse_eapol_key_packet(eapol_packet_t *eapol_packet);

/**
 * @brief Parses PMKIDs from EAPoL-Key packet
 * 
 * @param eapol_key 
 * @return pmkid_item_t* linked list of PMKIDs if parsing successful
 * @return \c NULL if no key data present
 * @return \c NULL if key data are encrypted
 * @return \c NULL parsing fails
 */
pmkid_item_t *parse_pmkid(eapol_key_packet_t *eapol_key);

/**
 * @brief Parses SSID from a management frame body (probe/beacon/assoc response).
 *
 * Walks the 802.11 tagged parameters starting after the fixed fields.
 * Tag ID 0 = SSID element.
 *
 * Fixed field sizes:
 *   Beacon / Probe Response : 12 bytes (timestamp 8 + interval 2 + capabilities 2)
 *   Association Response    :  6 bytes (capabilities 2 + status 2 + assoc_id 2)
 *
 * @param body        pointer to management frame body (after 24-byte 802.11 MAC header)
 * @param body_len    length of the body in bytes
 * @param fixed_len   number of fixed-field bytes to skip before tagged params
 * @param out_ssid    output buffer, must be at least 33 bytes
 * @return true  if a non-empty valid SSID was found and written to out_ssid
 * @return false if SSID tag is absent, empty, or malformed
 */
bool parse_ssid_from_mgmt(const uint8_t *body, int body_len,
                          int fixed_len, char *out_ssid);

#endif
