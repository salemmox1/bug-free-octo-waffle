/**
 * @file attack_mac.h
 * @brief Provides interface for MAC collector attack on open networks.
 *
 * Passively sniffs management frames on the target AP channel and collects
 * unique source MAC addresses of nearby clients using data_frame_mac_header_t.
 */

#ifndef ATTACK_MAC_H
#define ATTACK_MAC_H

#include "attack.h"

/**
 * @brief Starts MAC collector attack.
 *
 * @param attack_config attack configuration with valid ap_record
 */
void attack_mac_start(attack_config_t *attack_config);

/**
 * @brief Stops MAC collector attack and writes results to status content.
 *
 * Result format: [count: 1 byte] [MAC_0..N: 6 bytes each]
 */
void attack_mac_stop();

#endif
