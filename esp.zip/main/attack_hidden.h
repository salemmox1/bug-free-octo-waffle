/**
 * @file attack_hidden.h
 * @brief Provides interface for hidden SSID discovery attack.
 *
 * Passively sniffs probe responses and association responses from the
 * target BSSID. Uses parse_ssid_from_mgmt() from frame_analyzer_parser
 * to extract the SSID from 802.11 tagged parameters.
 */

#ifndef ATTACK_HIDDEN_H
#define ATTACK_HIDDEN_H

#include "attack.h"

/**
 * @brief Starts hidden SSID discovery attack.
 *
 * @param attack_config attack configuration with valid ap_record
 */
void attack_hidden_start(attack_config_t *attack_config);

/**
 * @brief Stops hidden SSID discovery and writes result to status content.
 *
 * Result format: [ssid_len: 1 byte] [ssid: ssid_len bytes]
 * ssid_len == 0 means SSID was not found.
 */
void attack_hidden_stop();

#endif
