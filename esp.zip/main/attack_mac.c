/**
 * @file attack_mac.c
 * @brief Implements MAC collector — passively sniffs client MACs on open networks.
 *
 * Uses data_frame_mac_header_t from frame_analyzer_types.h to parse
 * 802.11 management frames cleanly instead of raw byte offsets.
 * Uses wifictl_sniffer_start/stop from wifi_controller (consistent with other attacks).
 *
 * No deauth, no injection, no association — pure passive promiscuous sniff.
 */

#include "attack_mac.h"

#include <string.h>
#include <stdlib.h>
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_err.h"
#include "esp_wifi.h"
#include "esp_wifi_types.h"

#include "attack.h"
#include "wifi_controller.h"
#include "frame_analyzer_types.h"

static const char *TAG = "main:attack_mac";
static const wifi_ap_record_t *ap_record = NULL;

#define MAC_LIST_MAX 64
static uint8_t mac_list[MAC_LIST_MAX][6];
static int mac_count = 0;

static bool mac_already_seen(const uint8_t *mac) {
    for (int i = 0; i < mac_count; i++) {
        if (memcmp(mac_list[i], mac, 6) == 0) return true;
    }
    return false;
}

static void mac_sniffer_cb(void *buf, wifi_promiscuous_pkt_type_t type) {
    if (type != WIFI_PKT_MGMT || mac_count >= MAC_LIST_MAX) return;

    wifi_promiscuous_pkt_t *pkt = (wifi_promiscuous_pkt_t *) buf;
    if (pkt->rx_ctrl.sig_len < sizeof(data_frame_mac_header_t)) return;

    data_frame_mac_header_t *mac_hdr = (data_frame_mac_header_t *) pkt->payload;
    if (mac_hdr->frame_control.type != 0) return;

    uint8_t *src_mac = mac_hdr->addr2;
    if (src_mac[0] & 0x01) return;
    if (ap_record && memcmp(src_mac, ap_record->bssid, 6) == 0) return;
    if (ap_record && memcmp(mac_hdr->addr3, ap_record->bssid, 6) != 0) return;

    if (!mac_already_seen(src_mac)) {
        memcpy(mac_list[mac_count], src_mac, 6);
        mac_count++;
        ESP_LOGI(TAG, "New client MAC [%d]: %02X:%02X:%02X:%02X:%02X:%02X",
                 mac_count, src_mac[0], src_mac[1], src_mac[2],
                 src_mac[3], src_mac[4], src_mac[5]);
    }
}

void attack_mac_start(attack_config_t *attack_config) {
    ESP_LOGI(TAG, "Starting MAC collector attack...");
    ap_record = attack_config->ap_record;
    mac_count = 0;
    memset(mac_list, 0, sizeof(mac_list));

    // Use wifi_controller sniffer — handles deauth of connected STAs correctly
    wifictl_sniffer_filter_frame_types(false, true, false);
    wifictl_sniffer_start(ap_record->primary);
    // Override callback with ours after sniffer_start sets its own
    esp_wifi_set_promiscuous_rx_cb(&mac_sniffer_cb);

    attack_update_status(RUNNING);
    ESP_LOGI(TAG, "Listening on channel %d for client MACs...", ap_record->primary);
}

void attack_mac_stop() {
    ESP_LOGI(TAG, "Stopping MAC collector — found %d unique MACs", mac_count);
    wifictl_sniffer_stop();

    unsigned content_size = 1 + mac_count * 6;
    char *content = attack_alloc_result_content(content_size);
    if (content == NULL) {
        ESP_LOGE(TAG, "Failed to allocate result content");
        return;
    }

    content[0] = (uint8_t) mac_count;
    for (int i = 0; i < mac_count; i++) {
        memcpy(content + 1 + i * 6, mac_list[i], 6);
    }

    attack_update_status(FINISHED);
    ap_record = NULL;
    mac_count = 0;
}
