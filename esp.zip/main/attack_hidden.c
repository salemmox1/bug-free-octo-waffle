/**
 * @file attack_hidden.c
 * @brief Implements hidden SSID discovery via passive probe/assoc response sniffing.
 *
 * Uses wifictl_sniffer_start/stop (consistent with other attacks),
 * data_frame_mac_header_t for clean frame parsing,
 * and parse_ssid_from_mgmt() from frame_analyzer_parser for tagged param parsing.
 */

#include "attack_hidden.h"

#include <string.h>
#include <stdlib.h>
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_err.h"
#include "esp_wifi.h"
#include "esp_wifi_types.h"

#include "attack.h"
#include "wifi_controller.h"
#include "frame_analyzer_types.h"
#include "frame_analyzer_parser.h"

static const char *TAG = "main:attack_hidden";
static const wifi_ap_record_t *ap_record = NULL;
static char discovered_ssid[33] = {0};
static bool ssid_found = false;

// 802.11 management frame subtypes
#define MGMT_SUBTYPE_ASSOC_RESP  0x01
#define MGMT_SUBTYPE_PROBE_RESP  0x05

// Fixed-field byte counts before tagged parameters
#define FIXED_LEN_PROBE_RESP   12   // timestamp(8) + interval(2) + capabilities(2)
#define FIXED_LEN_ASSOC_RESP    6   // capabilities(2) + status(2) + assoc_id(2)

// 802.11 MAC header size
#define DOT11_MAC_HEADER_LEN   24

static void hidden_sniffer_cb(void *buf, wifi_promiscuous_pkt_type_t type) {
    if (type != WIFI_PKT_MGMT || ssid_found) return;

    wifi_promiscuous_pkt_t *pkt = (wifi_promiscuous_pkt_t *) buf;
    int len = pkt->rx_ctrl.sig_len;

    if (len < (int) sizeof(data_frame_mac_header_t)) return;

    data_frame_mac_header_t *mac_hdr = (data_frame_mac_header_t *) pkt->payload;

    if (mac_hdr->frame_control.type != 0) return;

    uint8_t subtype = mac_hdr->frame_control.subtype;
    if (subtype != MGMT_SUBTYPE_PROBE_RESP && subtype != MGMT_SUBTYPE_ASSOC_RESP) return;

    // Source MAC must be our target AP's BSSID
    if (ap_record && memcmp(mac_hdr->addr2, ap_record->bssid, 6) != 0) return;

    const uint8_t *body     = pkt->payload + DOT11_MAC_HEADER_LEN;
    int            body_len = len - DOT11_MAC_HEADER_LEN;
    if (body_len <= 0) return;

    int fixed_len = (subtype == MGMT_SUBTYPE_PROBE_RESP) ? FIXED_LEN_PROBE_RESP
                                                          : FIXED_LEN_ASSOC_RESP;

    char ssid_buf[33] = {0};
    if (parse_ssid_from_mgmt(body, body_len, fixed_len, ssid_buf)) {
        memcpy(discovered_ssid, ssid_buf, 33);
        ssid_found = true;
        ESP_LOGI(TAG, "Hidden SSID discovered: \"%s\" (subtype=0x%02X)",
                 discovered_ssid, subtype);
    }
}

void attack_hidden_start(attack_config_t *attack_config) {
    ESP_LOGI(TAG, "Starting hidden SSID discovery...");
    ap_record  = attack_config->ap_record;
    ssid_found = false;
    memset(discovered_ssid, 0, sizeof(discovered_ssid));

    // Use wifi_controller sniffer — handles deauth of connected STAs correctly
    wifictl_sniffer_filter_frame_types(false, true, false);
    wifictl_sniffer_start(ap_record->primary);
    // Override callback with ours
    esp_wifi_set_promiscuous_rx_cb(&hidden_sniffer_cb);

    attack_update_status(RUNNING);
    ESP_LOGI(TAG, "Waiting for probe/assoc response from %02X:%02X:%02X:%02X:%02X:%02X ch%d",
             ap_record->bssid[0], ap_record->bssid[1], ap_record->bssid[2],
             ap_record->bssid[3], ap_record->bssid[4], ap_record->bssid[5],
             ap_record->primary);
}

void attack_hidden_stop() {
    wifictl_sniffer_stop();

    // Result: [ssid_len: 1 byte] [ssid: ssid_len bytes]  (ssid_len==0 = not found)
    unsigned ssid_len = ssid_found ? strlen(discovered_ssid) : 0;
    char *content = attack_alloc_result_content(1 + ssid_len);

    if (content) {
        content[0] = (uint8_t) ssid_len;
        if (ssid_len > 0) {
            memcpy(content + 1, discovered_ssid, ssid_len);
            ESP_LOGI(TAG, "Result: SSID = \"%s\"", discovered_ssid);
        } else {
            ESP_LOGW(TAG, "SSID not discovered within timeout");
        }
    }

    attack_update_status(FINISHED);
    ap_record  = NULL;
    ssid_found = false;
}
